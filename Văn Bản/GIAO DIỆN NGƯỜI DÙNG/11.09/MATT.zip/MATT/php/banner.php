<div class="component osw-homepage osw-page-content-offset-none">
    <div class="component-content">
        <div class="osw-page-header">
            <div class="component osw-gridcontainerline grid-container full">
                <div class="component osw-gridx grid-x">
                    <div class="component osw-contentblock osw-contentblock-imagefull osw-contentblock-imagefull-contentposition-010 osw-contentblock-imagefull-update cell small-12 medium-12 large-12 osw-bgfiltercolor-black osw-bgfilteropacity-030 osw-bgstrength-dark osw-color-white osw-contentblock-imagefull-cover osw-contentblock-titlesize-h2 osw-minheight-medium osw-paddingbottom-large osw-paddingtop-2large osw-paddingright-2large osw-paddingleft-2large text-center">
                        <div class="component-content">
                            <div class="osw-contentblock-imagefull-container">
                                <div class="osw-contentblock-imagefull-container-img">
                                    <img src="img/matt2.jpg" id="banner-img" alt="Banner" width="5197" height="3465" data-variantitemid="{2EC5E74F-07DD-4E3A-A74C-D96317D20023}" data-variantfieldname="Main Image">
                                </div>
                                <div class="osw-contentblock-imagefull-container-content">
                                    <div class="osw-contentblock-imagefull-container-content-top">
                                        <div class="osw-contentblock-title">
                                            <h1 class="field-title" style="text-transform: uppercase;">
                                            Mái Ấm Truyền Tin
                                            </h1>
                                            <h1 class="field-title" style="text-transform: uppercase;">
                                            ngôi nhà chung của các trẻ
                                            </h1>
                                        </div>
                                    </div>
                                    <div class="osw-contentblock-imagefull-container-content-middle">
                                        <div class="osw-contentblock-maintext field-text mt-3">
                                            Đây sẽ là một đoạn văn ngắn gọn trong 1 dòng. Mô tả một nội dung bất kỳ mà mái ấm muốn truyền đạt cho mọi người.
                                        </div>
                                        <form class="form-group form-inline my-5 bg-white p-3" id="search-nav" action="tim-kiem.php" method="GET">
                                            <input class="form-control m-0 h-100" type="text" name="search" placeholder="Gõ vào đây để tìm kiếm" aria-label="Search">
                                            <button type="submit" class="btn btn-primary">Tìm kiếm</button>
                                        </form>
                                    </div>
                                    <div class="osw-contentblock-imagefull-container-content-bottom">
                                        <div class="osw-contentblock-additionaltext field-additional-text">
                                            Mái Ấm Truyền Tin, một mái ấm cho mọi nhà.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>   
        </div>
    </div>
</div>